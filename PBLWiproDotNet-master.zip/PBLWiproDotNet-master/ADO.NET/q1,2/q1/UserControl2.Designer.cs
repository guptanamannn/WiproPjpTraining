﻿using System;

namespace q1
{
    partial class UserControl2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2IN = new System.Windows.Forms.Panel();
            this.txttitle2 = new System.Windows.Forms.TextBox();
            this.btnexit2 = new System.Windows.Forms.Button();
            this.btn3back = new System.Windows.Forms.Button();
            this.btnsub2 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2IN.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2IN
            // 
            this.panel2IN.Controls.Add(this.txttitle2);
            this.panel2IN.Controls.Add(this.btnexit2);
            this.panel2IN.Controls.Add(this.btn3back);
            this.panel2IN.Controls.Add(this.btnsub2);
            this.panel2IN.Controls.Add(this.textBox9);
            this.panel2IN.Controls.Add(this.textBox8);
            this.panel2IN.Controls.Add(this.textBox7);
            this.panel2IN.Controls.Add(this.textBox6);
            this.panel2IN.Controls.Add(this.textBox5);
            this.panel2IN.Controls.Add(this.dateTimePicker1);
            this.panel2IN.Controls.Add(this.textBox4);
            this.panel2IN.Controls.Add(this.textBox3);
            this.panel2IN.Controls.Add(this.textBox2);
            this.panel2IN.Controls.Add(this.textBox1);
            this.panel2IN.Location = new System.Drawing.Point(39, 47);
            this.panel2IN.Name = "panel2IN";
            this.panel2IN.Size = new System.Drawing.Size(702, 443);
            this.panel2IN.TabIndex = 7;
            // 
            // txttitle2
            // 
            this.txttitle2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttitle2.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttitle2.Location = new System.Drawing.Point(268, 9);
            this.txttitle2.Name = "txttitle2";
            this.txttitle2.ReadOnly = true;
            this.txttitle2.Size = new System.Drawing.Size(315, 31);
            this.txttitle2.TabIndex = 13;
            this.txttitle2.Text = "Update Details";
            // 
            // btnexit2
            // 
            this.btnexit2.Location = new System.Drawing.Point(75, 323);
            this.btnexit2.Name = "btnexit2";
            this.btnexit2.Size = new System.Drawing.Size(94, 36);
            this.btnexit2.TabIndex = 12;
            this.btnexit2.Text = "Exit";
            this.btnexit2.UseVisualStyleBackColor = true;
            this.btnexit2.Click += new System.EventHandler(this.btnexit2_Click);
            // 
            // btn3back
            // 
            this.btn3back.Location = new System.Drawing.Point(496, 323);
            this.btn3back.Name = "btn3back";
            this.btn3back.Size = new System.Drawing.Size(87, 36);
            this.btn3back.TabIndex = 11;
            this.btn3back.Text = "Cancel";
            this.btn3back.UseVisualStyleBackColor = true;
            this.btn3back.Click += new System.EventHandler(this.btn3back_Click);
            // 
            // btnsub2
            // 
            this.btnsub2.Location = new System.Drawing.Point(372, 323);
            this.btnsub2.Name = "btnsub2";
            this.btnsub2.Size = new System.Drawing.Size(98, 36);
            this.btnsub2.TabIndex = 10;
            this.btnsub2.Text = "Update";
            this.btnsub2.UseVisualStyleBackColor = true;
            this.btnsub2.Click += new System.EventHandler(this.btnsub2_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(75, 270);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(214, 22);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "JoiningDate";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(75, 217);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(214, 22);
            this.textBox8.TabIndex = 8;
            this.textBox8.Text = "Qualification";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(75, 163);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(214, 22);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "Designation";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(75, 113);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(214, 22);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "EmpName";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(75, 59);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(214, 22);
            this.textBox5.TabIndex = 5;
            this.textBox5.Text = "EmployeeID";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(333, 268);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(250, 22);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(333, 217);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(250, 22);
            this.textBox4.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(333, 163);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(250, 22);
            this.textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(333, 113);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(250, 22);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(333, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(250, 22);
            this.textBox1.TabIndex = 0;
            // 
            // UserControl2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2IN);
            this.Name = "UserControl2";
            this.Size = new System.Drawing.Size(786, 557);
            this.panel2IN.ResumeLayout(false);
            this.panel2IN.PerformLayout();
            this.ResumeLayout(false);

        }

        private void btnsub2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btn3back_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btnexit2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Panel panel2IN;
        private System.Windows.Forms.TextBox txttitle2;
        private System.Windows.Forms.Button btnexit2;
        private System.Windows.Forms.Button btn3back;
        private System.Windows.Forms.Button btnsub2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }

}
