﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    class Employee : Person
    {
        public double Salary { get; set; }

    }
}
