﻿using System;
using System.Collections.Generic;
using System.Text;

namespace q2
{
    public interface Ipayable
    {
        void Calculatepay();
    }
}
