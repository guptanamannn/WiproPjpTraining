﻿using System;
using System.Collections.Generic;
using System.Text;

namespace q2
{
    class Person
    {
        private string FirstName;
        private string LastName;
        private string EmailAddress;
        private DateTime DateofBirth;

        public string firstn { get; set; }

        public string lastn { get; set; }
        public string email { get; set; }
        public string dob { get; set; }

    }
}
