
select * from Employees where HireDate LIKE '%1981%'