
UPDATE employee
SET lname = 'Drexler' 
where emp_id = 'VPA30890F'
