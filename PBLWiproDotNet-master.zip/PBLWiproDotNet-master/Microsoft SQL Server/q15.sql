
Insert into jobs
(job_id , job_desc , min_lvl , max_lvl)
Values
('15','Human Resource Manager','138','300')