
sselect lname,SUBSTRING(lname,LEN(lname)-2,LEN(lname)) as new from employee