
select lname,REPLICATE('*',LEN(lname)) as new from employee