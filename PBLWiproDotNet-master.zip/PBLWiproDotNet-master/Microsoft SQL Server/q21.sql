
SELECT  FirstName,LastName, salary 
FROM employees 
WHERE  salary like �%0�;