
SELECT *
FROM employees
WHERE mod(salary,2) = 1;