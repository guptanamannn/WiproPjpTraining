
select Title , COUNT(Title) as no_of_Employees from employees
Group by Title