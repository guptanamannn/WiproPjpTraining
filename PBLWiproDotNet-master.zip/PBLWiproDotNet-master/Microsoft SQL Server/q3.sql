
select title_id, price as old_price, ((1.2)*price) as new_price
from titles;

