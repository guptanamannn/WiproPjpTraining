
select title,price from titles where price > 20 AND price < 55