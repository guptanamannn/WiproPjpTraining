
select HireDate from Employees where HireDate >= '1990-12-1' 