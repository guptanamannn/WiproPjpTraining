
select Hiredate from Employees