﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.IO.Compression;

namespace Products.Models
{
    public class Product
    {
        [Required]
        [Key]
        public int ProductId { get; set; }
        [Required]
        [StringLength(50),MinLength(1)]
        public string ProductName { get; set; }
        [Required]
        [StringLength(200)]
        public string Description { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        [Range(0,99999.99)]
        public double UnitPrice{ get; set; }
        [Required]
        public int ReorderLevel { get; set; }
    }
}
