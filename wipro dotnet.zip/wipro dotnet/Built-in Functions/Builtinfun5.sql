select * from employee where len(cast(salary as nvarchar))=3
