select * from employee where right(cast(salary as nvarchar),1)=0
