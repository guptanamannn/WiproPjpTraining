
select * from employee where (salary=2000 or salary=3000 or salary=5000) and (job='analyst' or job='president') and year(hire_date)=1981