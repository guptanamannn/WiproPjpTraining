insert into employee values
(
'PSA89096M',
'sindhu',
'S',
'kande',
14,
100,
'9999',
'1992-08-19')