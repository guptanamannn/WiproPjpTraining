

select count(emp_id) as Totalempineachgrade from employee group by grade