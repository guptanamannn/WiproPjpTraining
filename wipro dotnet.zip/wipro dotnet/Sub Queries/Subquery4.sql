

select * from employee where dept='sales' and (manager='king' or manager='jones')