﻿namespace WindowsForms4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btndot = new System.Windows.Forms.Button();
            this.btnclr = new System.Windows.Forms.Button();
            this.btnplus = new System.Windows.Forms.Button();
            this.btninto = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.btnminus = new System.Windows.Forms.Button();
            this.btnby = new System.Windows.Forms.Button();
            this.btnequal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(177, 135);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(51, 44);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(280, 135);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(52, 44);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(389, 135);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(52, 44);
            this.btn3.TabIndex = 2;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(177, 185);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(51, 45);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(280, 185);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(52, 45);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(389, 187);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(52, 45);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(177, 236);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(51, 51);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(280, 237);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(52, 50);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(389, 238);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(52, 50);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(177, 294);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(51, 47);
            this.btn0.TabIndex = 9;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.button10_Click);
            // 
            // btndot
            // 
            this.btndot.Location = new System.Drawing.Point(280, 293);
            this.btndot.Name = "btndot";
            this.btndot.Size = new System.Drawing.Size(52, 48);
            this.btndot.TabIndex = 10;
            this.btndot.Text = ".";
            this.btndot.UseVisualStyleBackColor = true;
            this.btndot.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnclr
            // 
            this.btnclr.Location = new System.Drawing.Point(389, 293);
            this.btnclr.Name = "btnclr";
            this.btnclr.Size = new System.Drawing.Size(52, 47);
            this.btnclr.TabIndex = 11;
            this.btnclr.Text = "clear";
            this.btnclr.UseVisualStyleBackColor = true;
            this.btnclr.Click += new System.EventHandler(this.button12_Click);
            // 
            // btnplus
            // 
            this.btnplus.Location = new System.Drawing.Point(496, 135);
            this.btnplus.Name = "btnplus";
            this.btnplus.Size = new System.Drawing.Size(49, 44);
            this.btnplus.TabIndex = 25;
            this.btnplus.Text = "+";
            this.btnplus.UseVisualStyleBackColor = true;
            this.btnplus.Click += new System.EventHandler(this.button13_Click);
            // 
            // btninto
            // 
            this.btninto.Location = new System.Drawing.Point(496, 191);
            this.btninto.Name = "btninto";
            this.btninto.Size = new System.Drawing.Size(49, 41);
            this.btninto.TabIndex = 25;
            this.btninto.Text = "*";
            this.btninto.UseVisualStyleBackColor = true;
            this.btninto.Click += new System.EventHandler(this.button14_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.Location = new System.Drawing.Point(173, 62);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(372, 20);
            this.txtDisplay.TabIndex = 18;
            this.txtDisplay.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnminus
            // 
            this.btnminus.Location = new System.Drawing.Point(496, 240);
            this.btnminus.Name = "btnminus";
            this.btnminus.Size = new System.Drawing.Size(49, 48);
            this.btnminus.TabIndex = 26;
            this.btnminus.Text = "-";
            this.btnminus.UseVisualStyleBackColor = true;
            this.btnminus.Click += new System.EventHandler(this.button15_Click);
            // 
            // btnby
            // 
            this.btnby.Location = new System.Drawing.Point(496, 294);
            this.btnby.Name = "btnby";
            this.btnby.Size = new System.Drawing.Size(49, 46);
            this.btnby.TabIndex = 27;
            this.btnby.Text = "/";
            this.btnby.UseVisualStyleBackColor = true;
            this.btnby.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnequal
            // 
            this.btnequal.Location = new System.Drawing.Point(572, 135);
            this.btnequal.Name = "btnequal";
            this.btnequal.Size = new System.Drawing.Size(75, 206);
            this.btnequal.TabIndex = 28;
            this.btnequal.Text = "=";
            this.btnequal.UseVisualStyleBackColor = true;
            this.btnequal.Click += new System.EventHandler(this.button17_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnequal);
            this.Controls.Add(this.btnby);
            this.Controls.Add(this.btnminus);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btninto);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.btnclr);
            this.Controls.Add(this.btndot);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btndot;
        private System.Windows.Forms.Button btnclr;
        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Button btninto;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Button btnminus;
        private System.Windows.Forms.Button btnby;
        private System.Windows.Forms.Button btnequal;
    }
}

