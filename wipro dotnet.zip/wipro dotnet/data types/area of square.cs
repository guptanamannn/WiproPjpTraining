using System;

namespace myapp
{
    class A
{
	static void Main(string[] arg)
	{
	     string a;
	    a= Console.ReadLine();
	int b=Convert.ToInt32(a);
	int area=b*b;
	Console.WriteLine(area);
	}
}
}